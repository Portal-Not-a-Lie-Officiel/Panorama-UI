'use strict';

const HideHud = {
	CROSSHAIR: 1 << 8,
	LEADERBOARDS: 1 << 14
};
