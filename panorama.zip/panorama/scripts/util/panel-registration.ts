'use strict';

//--------------------------------------------------------------------------------------------------
// Common place to register new panel type with panorama
//--------------------------------------------------------------------------------------------------

UiToolkitAPI.RegisterPanel2d('LineGraph', 'file://{resources}/layout/components/graphs/line-graph.xml');
UiToolkitAPI.RegisterPanel2d('VersionInfo', 'file://{resources}/layout/components/version-info.xml');
